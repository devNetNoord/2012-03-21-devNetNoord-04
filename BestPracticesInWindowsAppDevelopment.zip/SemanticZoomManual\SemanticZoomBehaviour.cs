﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Interactivity;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace SemanticZoomManual.Behavior
{
    /// <summary>
    /// A behavior that allows to customize the semantic zoom behavior.
    /// </summary>
    public class SemanticZoomBehaviour : Behavior<SemanticZoom>
    {
        /// <summary>
        /// Called after the behavior is attached to an AssociatedObject.
        /// </summary>
        protected override void OnAttached()
        {
            base.OnAttached();
            this.AssociatedObject.ViewChangeStarted += ViewChangeStarted;
        }

        /// <summary>
        /// Called when the behavior is being detached from its AssociatedObject, but before it has actually occurred.
        /// </summary>
        protected override void OnDetaching()
        {
            base.OnDetaching();
            this.AssociatedObject.ViewChangeStarted -= ViewChangeStarted;
        }

        void ViewChangeStarted(object sender, SemanticZoomViewChangedEventArgs e)
        {
            //Bij het uitzoomen hoeft er niets te gebeuren
            if (e.IsSourceZoomedInView) return;

            //De behavior is gebaseerd op een SemanticZoom object die zowel voor in- als uitgezoomde weergave een gridview bevat
            GridView zoomedInGridView = (GridView)AssociatedObject.ZoomedInView;
            GridView zoomedOutGridView = (GridView)AssociatedObject.ZoomedOutView;

            if (zoomedInGridView == null || zoomedOutGridView == null) return;

            //Om het goede item in beeld te scrollen bepalen we de index van het geselecteerde item
            var index = zoomedOutGridView.Items.IndexOf(e.SourceItem.Item);
            if (index == -1) return;

            //Om de behavior goed te laten werken scrollen we de GridView terug naar punt 0,0
            SemanticZoomLocation zoomLoc = new SemanticZoomLocation();
            zoomLoc.Bounds = new Windows.Foundation.Rect(0, 0, 1, 1);
            zoomLoc.Item = zoomedInGridView.Items[0];
            zoomedInGridView.Focus(FocusState.Pointer);
            zoomedInGridView.MakeVisible(zoomLoc);
            
            //Vervolgens scrollen we het geselecteerde item in beeld
            zoomedInGridView.ScrollIntoView(zoomedInGridView.Items[index], ScrollIntoViewAlignment.Leading);
            
        }
    }
}
