﻿using NotificationsExtensions.TileContent;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
 

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace SemanticZoomManual
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            //Onderstaande code werkt livetiles bij via de server of lokaal. 
            //Zie http://msdn.microsoft.com/en-us/library/windows/apps/hh761491.aspx voor beschikbare templates

            //Om een serie tiles mogelijk te maken enablen we de NotificationQueue
            TileUpdateManager.CreateTileUpdaterForApplication().EnableNotificationQueue(true);

            //We stellen het updateinterval in op ieder half uur
            PeriodicUpdateRecurrence recurrence = PeriodicUpdateRecurrence.HalfHour;

            //Om meer dan tileupdate tegelijk mogelijk te maken geven we een batch van 5 uris mee
            List<Uri> uris = new List<Uri>();
            uris.Add(new Uri("http://livetile.tomverhoeff.nl/1.xml"));
            uris.Add(new Uri("http://livetile.tomverhoeff.nl/2.xml"));
            uris.Add(new Uri("http://livetile.tomverhoeff.nl/3.xml"));
            uris.Add(new Uri("http://livetile.tomverhoeff.nl/3.xml"));
            uris.Add(new Uri("http://livetile.tomverhoeff.nl/4.xml"));
            
            //Vervolgens roepen we de TileUpdateManager aan om daadwerkelijk te starten met updaten
            TileUpdateManager.CreateTileUpdaterForApplication().StartPeriodicUpdateBatch(uris, recurrence);


            /*
            //De andere optie is lokaal updaten
            //Met behulp van de NotificationExtensions library kun je eenvoudig 
            //De benodigde objecten aanmaken
              
            //Beginnen met de brede tile
            var tileContent = TileContentFactory.CreateTileWideText03();
            tileContent.TextHeadingWrap.Text = "Het is leuk bij devNetNoord";

            //Daarna aanvullen met de square tile
            var squareTileContent = TileContentFactory.CreateTileSquareText04();
            squareTileContent.TextBodyWrap.Text = "Het is leuk bij devNetNoord";
            tileContent.SquareContent = squareTileContent;

            //En direct lokaal updaten
            TileUpdateManager.CreateTileUpdaterForApplication().Update(tileContent.CreateNotification());

            */
    
        }

        
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            //In de OnNavigatedTo registreren we een eventhandler voor het DataRequested element.
            //Dit event wordt gevuurd als de gebruiken de share charm gebruikt
            DataTransferManager dataTransferManager = DataTransferManager.GetForCurrentView();
            dataTransferManager.DataRequested += dataTransferManager_DataRequested;
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            base.OnNavigatedFrom(e);

            //Bij het wegnavigeren ruimen we de eventhandler weer netjes op 
            DataTransferManager dataTransferManager = DataTransferManager.GetForCurrentView();
            dataTransferManager.DataRequested -= dataTransferManager_DataRequested;
        }

        void dataTransferManager_DataRequested(DataTransferManager sender, DataRequestedEventArgs args)
        {

            //Aan het event zit een DataRequest object. Deze vullen we met de data die we willen delen
            //In dit geval een simpele url waar we een titel en omschrijving aan meegeven
            DataRequest request = args.Request;
            request.Data.Properties.Title = "devNetNoord";
            request.Data.Properties.Description = "Het is leuk bij devNetNoord";
            var link = new Uri("http://www.devnetnoord.nl");
            request.Data.SetUri(link);
            
        }
    }
}
